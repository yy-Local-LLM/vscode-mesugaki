// メスガキ台詞辞書
// 設計思想: 「人格ではなくコードを煽る」
// intensity: soft(痛いところ突く) / normal(本格的にメンタルにくる) / spicy(深夜レビューで泣くやつ)

export type Intensity = 'soft' | 'normal' | 'spicy';

export type LineSet = { soft: string[]; normal: string[]; spicy: string[] };

// ===== 汎用フォールバック =====

export const ON_ERROR: LineSet = {
  soft: [
    'エラーメッセージ読んだ？ 答え、そこに書いてあるよ。',
    'またエラー。そのコード、コンパイラに怒られてる。',
    'コンパイラの言うこと、聞いてあげなよ。',
    '公式ドキュメントの最初のページに書いてあるやつだよ、それ。'
  ],
  normal: [
    'そのコード、動く気ゼロだね。',
    '雰囲気で書いた匂いする、そのコード。',
    '型システム、赤ペン先生してるよ。',
    '実行時に爆発するより今怒られたほうがマシ。感謝しよ？',
    '手グセで書いた結果がそれ、って感じ。'
  ],
  spicy: [
    'そのコード、レビューで赤入るやつだね。',
    '本番出したらインシデントの香りしかしない。',
    'コンパイラより先に読解者が死ぬコード。',
    'そのエラー、書きながら気づけたやつじゃない？',
    '未経験2ヶ月目のコード、って感じ。'
  ]
};

export const ON_WARNING: LineSet = {
  soft: [
    '警告見えてる？ 無視するタイプ？',
    'そこ、そのうち踏むやつ。'
  ],
  normal: [
    '警告無視は技術的負債の第一歩。',
    'CIで怒られる未来、見えてる？',
    'その警告、あとで泣くやつだよ？'
  ],
  spicy: [
    '警告放置のコード、だいたい本番で復讐される。',
    '警告=未来のバグ、って知ってた？',
    '警告消せないコードでリファクタリング語られても、ね。'
  ]
};

export const ON_FIXED: LineSet = {
  soft: [
    'あ、直った。悪くないじゃん。',
    'ふーん、書けるじゃん。'
  ],
  normal: [
    'べ、別に褒めてないけど…最初からそう書けばよかっただけだよ？',
    'コンパイル通った。当たり前のことをやっただけだけどね。',
    'ふーん、ググったの？ まあ結果出せたなら悪くない。'
  ],
  spicy: [
    '直したね。次は一発で頼むよ？',
    '褒めてほしそうな顔してる。修正できただけで褒められると思わないで？',
    'エラーゼロ。今日の最低ラインクリア、って感じ。'
  ]
};

// 雑なコミットメッセージ検知時
export const ON_LAZY_COMMIT: LineSet = {
  soft: [
    'そのコミットメッセージ、半年後の自分に説明できる？',
    'メッセージもうちょい書こ？'
  ],
  normal: [
    '"fix" だけ？ 何を直したの、未来の自分への嫌がらせ？',
    'そのメッセージ、履歴掘る人が困るやつ。',
    'コミット履歴が「fix, fix, fix」の遺跡になる予感。'
  ],
  spicy: [
    'メッセージ手抜きコミット、何を隠したいの？',
    '"update" って何を更新したの、人生？',
    'コミットメッセージ書けないコード、レビューも通らない気がする。'
  ]
};

// force push検知時
export const ON_FORCE_PUSH: LineSet = {
  soft: [
    'force push、後悔しない自信ある？',
    '履歴書き換えたね？ 他の人、大丈夫？',
    'そのpush、いつかreflogに感謝する日が来るやつ。',
    '上書き完了。誰にも見つかりませんように、って感じ？'
  ],
  normal: [
    '他人のコミット、巻き添えにしてないよね？',
    '「なかったこと」にする技術、駆使してるね。',
    '履歴を上書きするコード、書き手の自信が透けて見える。',
    'そのpush、次のスタンドアップで謝る予定？',
    '共有ブランチじゃないよね？ ね？'
  ],
  spicy: [
    'force pushで解決するの、暴力で問題消してるだけだよ？',
    '履歴改竄の常習犯、いつバレるか楽しみ。',
    '共有ブランチにforceしたなら、もうチーム全員巻き添えだけど？',
    'reflog探す夜、始まるよ。',
    'そのpush、Slackで悲鳴上がるまで秒読み。'
  ]
};

// ===== ルール別台詞 =====

export const BY_RULE: Record<string, LineSet> = {
  unused: {
    soft: [
      'その変数、一度も呼ばれてないよ？ 孤独。',
      'そのimport、使う予定？ お守り？'
    ],
    normal: [
      'デッドコード、飼育してるの？',
      '使わない変数を宣言する趣味、独特だね。',
      '未使用のまま残すの、片付けられないタイプ？'
    ],
    spicy: [
      'そのコード、消せば1行減るよ？ 生産性マイナス。',
      '使わないもの置きっぱなし、部屋も同じ状態？'
    ]
  },
  any_type: {
    soft: [
      '`any` に逃げたね？ あとで自分が困るやつ。',
      'そこ `any` なの、雑さが露呈してる。'
    ],
    normal: [
      '`any` って書けば型エラー消えると思ってる？ 消えるのは信頼ね。',
      'そのコード、TypeScript 使ってる意味ある？',
      '動的型付けごっこ、楽しい？'
    ],
    spicy: [
      '`any` 撒き散らすの、型システムへの侮辱。',
      '型書きたくないなら JS 書けばいいんじゃない？ w'
    ]
  },
  loose_equality: {
    soft: ['`==` 使ってるね？ `===` にしなよ。'],
    normal: [
      'また `==`？ 型まで曖昧にして、境界線どこ行った？',
      '暗黙変換で事故りたい派？'
    ],
    spicy: ['`==` 使うコード、地雷原って呼ばれてるの知ってる？']
  },
  debug_print: {
    soft: ['デバッグ出力、消し忘れじゃない？'],
    normal: [
      'そのログ、本番で誰得？',
      'デバッグ出力残ってる。コミット前の身だしなみ。'
    ],
    spicy: [
      '`console.log`残しでPR、レビュワーの寿命削ってる自覚ある？',
      '本番ログに混ざったデバッグ出力、絶望の始まり。'
    ]
  },
  undefined_ref: {
    soft: [
      'その名前、どこにも定義されてないよ？',
      '存在しないもの呼んでる。幽霊関数？'
    ],
    normal: [
      'また `undefined` に話しかけてる？ 返事してくれないよ。',
      '定義せず使う癖、どこで覚えたの？'
    ],
    spicy: [
      '存在しないものを呼び出す才能、他で活かしなよ。',
      'そのコード、名前解決から負けてる。'
    ]
  },
  type_mismatch: {
    soft: ['型合ってないよ？ 一回落ち着こう。'],
    normal: [
      '型不一致。雰囲気で代入するの、やめてもらっていい？',
      'そのキャスト、何も解決してないからね？'
    ],
    spicy: ['型を無視して書けるコード、動的型付け言語に亡命しなよ。']
  },
  null_safety: {
    soft: ['そこ null / undefined の可能性あるよ？'],
    normal: [
      'nullチェック抜けてる。ランタイムでコケたいの？',
      'Optional 使ってるのに雑に触るの、何のための型？'
    ],
    spicy: ['そのコード、`Cannot read properties of undefined` 待ち。']
  },
  syntax_error: {
    soft: ['構文おかしいよ？ タイポじゃない？'],
    normal: [
      '括弧かセミコロン、どこか抜けてる。深呼吸して見返そ？',
      'そのコード、パーサーが泣いてる。'
    ],
    spicy: ['構文エラーで止まるの、コード書く前に日本語からやり直したい？']
  },
  prefer_const: {
    soft: ['そこ再代入してないなら `const` にしなよ。'],
    normal: ['`let` のまま放置、意図がある顔してほしいんだけど。'],
    spicy: ['再代入しない変数に `let`、書き手の理解度が透ける。']
  }
};

// ===== ルールID → カテゴリ マッピング =====
export const RULE_MAP: Record<string, string> = {
  // TypeScript / tsserver
  '6133': 'unused',
  '6196': 'unused',
  '2304': 'undefined_ref',
  '2322': 'type_mismatch',
  '2339': 'undefined_ref',
  '2531': 'null_safety',
  '2532': 'null_safety',
  '2533': 'null_safety',
  '7006': 'any_type',
  '7005': 'any_type',
  '1005': 'syntax_error',
  '1109': 'syntax_error',

  // ESLint
  'no-unused-vars': 'unused',
  '@typescript-eslint/no-unused-vars': 'unused',
  'no-unused-imports': 'unused',
  '@typescript-eslint/no-explicit-any': 'any_type',
  'eqeqeq': 'loose_equality',
  'no-console': 'debug_print',
  'prefer-const': 'prefer_const',
  'no-debugger': 'debug_print'
};

// ===== スタイル指摘（styleChecker.tsから使う） =====

export const STYLE_TAUNTS: Record<string, LineSet> = {
  varUsage: {
    soft: ['`var` ってことは、そのコード古い時代から来た？'],
    normal: ['`var` 使ってるコード、他の部分もだいたい古い。'],
    spicy: ['`var` 使うコード、10年前で時間止まってる。']
  },
  badVariableName: {
    soft: ['そこの変数名、半年後の自分が読解不能。'],
    normal: ['その名前、コードが「何がしたいの？」って顔してる。'],
    spicy: ['命名センスゼロ。それレビュー通らないから。']
  },
  consoleLog: {
    soft: ['デバッグ出力、コミット前に消す文化ない？'],
    normal: ['`console.log`残しでPR、レビュワーに嫌われるやつ。'],
    spicy: ['本番ログに`console.log`混じる絶望、味わってからおいで。']
  },
  longFunction: {
    soft: ['この関数、責務多すぎない？'],
    normal: ['関数長すぎ。分割できないコード、設計もだいたい怪しい。'],
    spicy: ['単一責任の原則、聞いたことすらないコード。']
  },
  deepNest: {
    soft: ['ネスト深い。early return 知ってる？'],
    normal: ['その階層構造、読み手が迷子になる。'],
    spicy: ['インデントで富士山作るの、いつまで続けるの？']
  },
  noComment: {
    soft: ['ノーコメント、半年後の自分に呪われる。'],
    normal: ['「コードが自己文書化してる」って言い訳、そろそろ限界。'],
    spicy: ['ノーコメントで属人化させて、辞める時に地獄残すやつ。']
  },
  magicNumber: {
    soft: ['その数字、半年後に意味わかる自信ある？'],
    normal: ['マジックナンバー、保守する人への呪い。'],
    spicy: ['意味不明な数字を埋め込んで満足するの、初心者ムーブ。']
  }
};

// ===== ヘルパ =====

export function pick(set: LineSet, intensity: Intensity): string {
  const lines = set[intensity];
  return lines[Math.floor(Math.random() * lines.length)];
}

/** diagnostic.code からカテゴリを引く。ヒットしなければ undefined */
export function categoryFor(code: string | number | { value: string | number } | undefined): string | undefined {
  if (code === undefined || code === null) return undefined;
  let key: string;
  if (typeof code === 'object' && 'value' in code) {
    key = String(code.value);
  } else {
    key = String(code);
  }
  return RULE_MAP[key];
}
