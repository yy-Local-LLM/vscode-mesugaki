import * as vscode from 'vscode';
import { ON_LAZY_COMMIT, ON_FORCE_PUSH, pick, Intensity } from './taunts';

// vscode.git 拡張のAPI型 (最小限)
interface GitCommit {
  hash: string;
  message: string;
  authorDate?: Date;
}

interface GitRepositoryState {
  HEAD?: { commit?: string; name?: string };
  onDidChange: vscode.Event<void>;
}

interface GitRepository {
  rootUri: vscode.Uri;
  state: GitRepositoryState;
  inputBox: { value: string };
  log(options: { maxEntries?: number }): Promise<GitCommit[]>;
}

interface GitAPI {
  repositories: GitRepository[];
  onDidOpenRepository: vscode.Event<GitRepository>;
}

interface GitExtension {
  getAPI(version: 1): GitAPI;
}

// 雑なコミットメッセージ判定パターン
const LAZY_PATTERNS: RegExp[] = [
  /^fix(ed|es)?$/i,
  /^update(d|s)?$/i,
  /^wip$/i,
  /^tmp$/i,
  /^temp$/i,
  /^test$/i,
  /^work$/i,
  /^edit(ed|s)?$/i,
  /^change(d|s)?$/i,
  /^a+$/i,          // "a", "aa", "aaa"
  /^\.+$/,          // "...", "."
  /^-+$/,           // "---"
  /^いろいろ/,
  /^色々/,
  /^修正$/,
  /^更新$/,
  /^てすと$/,
  /^テスト$/
];

/** メッセージが雑かどうか判定 */
export function isLazyMessage(msg: string): boolean {
  const firstLine = (msg.split('\n')[0] ?? '').trim();
  if (firstLine.length === 0) return true;

  // Conventional Commits形式（"feat:", "fix:", "chore:"等）はプレフィックス自体は許容、本体を見る
  const m = firstLine.match(/^(?:feat|fix|chore|docs|style|refactor|perf|test|build|ci|revert)(\([^)]*\))?!?:\s*(.*)$/i);
  if (m) {
    const body = m[2]?.trim() ?? '';
    if (body.length === 0) return true;
    if (body.length < 5) return true;
    return LAZY_PATTERNS.some((p) => p.test(body));
  }

  // プレフィックスなしで5文字未満は雑扱い
  if (firstLine.length < 5) return true;

  return LAZY_PATTERNS.some((p) => p.test(firstLine));
}

type NotifyFn = (message: string, kind?: 'info' | 'warn') => void;
type IntensityGetter = () => Intensity;

/**
 * リモート追跡ブランチのreflog（.git/logs/refs/remotes配下）を監視して、
 * 最新エントリが `forced-update` ならforce push検知として煽る。
 *
 * 注意: 自分のpush由来か、他人のforce pushをfetchしたのかは区別できない。
 * ただ「force pushが観測された」ことに変わりはないので煽る対象にする。
 */
function watchReflogForForcePush(
  repo: GitRepository,
  notify: NotifyFn,
  getIntensity: IntensityGetter
): vscode.Disposable[] {
  const disposables: vscode.Disposable[] = [];

  const logsDir = vscode.Uri.joinPath(repo.rootUri, '.git', 'logs', 'refs', 'remotes');
  const pattern = new vscode.RelativePattern(logsDir, '**/*');
  const watcher = vscode.workspace.createFileSystemWatcher(pattern);
  disposables.push(watcher);

  const handle = async (uri: vscode.Uri) => {
    try {
      const bytes = await vscode.workspace.fs.readFile(uri);
      const text = Buffer.from(bytes).toString('utf-8');
      const lines = text.split('\n').filter((l) => l.length > 0);
      if (lines.length === 0) return;
      const lastLine = lines[lines.length - 1];
      const tabIdx = lastLine.indexOf('\t');
      if (tabIdx < 0) return;
      const message = lastLine.slice(tabIdx + 1);
      if (message.includes('forced-update')) {
        notify(pick(ON_FORCE_PUSH, getIntensity()), 'warn');
      }
    } catch {
      // reflogが読めない/存在しない等は無視
    }
  };

  disposables.push(watcher.onDidChange(handle));
  disposables.push(watcher.onDidCreate(handle));

  return disposables;
}

/** VSCodeのGit拡張APIを取得 */
async function getGitApi(): Promise<GitAPI | undefined> {
  const ext = vscode.extensions.getExtension<GitExtension>('vscode.git');
  if (!ext) return undefined;
  if (!ext.isActive) {
    try {
      await ext.activate();
    } catch {
      return undefined;
    }
  }
  try {
    return ext.exports.getAPI(1);
  } catch {
    return undefined;
  }
}

/** 各リポジトリのHEADを追跡 */
const lastKnownHead = new Map<string, string>();

function watchRepository(
  repo: GitRepository,
  notify: NotifyFn,
  getIntensity: IntensityGetter
): vscode.Disposable {
  const key = repo.rootUri.toString();
  const initial = repo.state.HEAD?.commit;
  if (initial) lastKnownHead.set(key, initial);

  return repo.state.onDidChange(async () => {
    const current = repo.state.HEAD?.commit;
    if (!current) return;
    const prev = lastKnownHead.get(key);
    if (prev === current) return;

    lastKnownHead.set(key, current);
    // 初回HEAD検出時（起動直後 or 新規リポジトリ）は煽らない
    if (!prev) return;

    try {
      const log = await repo.log({ maxEntries: 1 });
      if (log.length === 0) return;
      const msg = log[0].message ?? '';

      // マージコミットは対象外
      if (/^Merge\b/i.test(msg.split('\n')[0] ?? '')) return;

      if (isLazyMessage(msg)) {
        notify(pick(ON_LAZY_COMMIT, getIntensity()), 'info');
      }
    } catch {
      // ログ取得失敗は無視
    }
  });
}

/** Git監視をセットアップ。Git拡張が無い環境では何もしない */
export async function setup(
  context: vscode.ExtensionContext,
  notify: NotifyFn,
  getIntensity: IntensityGetter
): Promise<void> {
  const api = await getGitApi();
  if (!api) return;

  const registerRepo = (repo: GitRepository) => {
    context.subscriptions.push(watchRepository(repo, notify, getIntensity));
    for (const d of watchReflogForForcePush(repo, notify, getIntensity)) {
      context.subscriptions.push(d);
    }
  };

  // 既存のリポジトリを監視
  for (const repo of api.repositories) {
    registerRepo(repo);
  }

  // 後から開かれたリポジトリも監視
  context.subscriptions.push(
    api.onDidOpenRepository((repo) => {
      registerRepo(repo);
    })
  );
}
