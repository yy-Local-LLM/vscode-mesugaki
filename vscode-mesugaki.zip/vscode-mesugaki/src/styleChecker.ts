import * as vscode from 'vscode';
import { STYLE_TAUNTS, pick, Intensity } from './taunts';

export interface StyleIssue {
  range: vscode.Range;
  ruleId: keyof typeof STYLE_TAUNTS;
  message: string;
}

// 対象言語（雑にJS/TS系）
const TARGET_LANGS = new Set(['javascript', 'typescript', 'javascriptreact', 'typescriptreact']);

export function shouldCheck(doc: vscode.TextDocument): boolean {
  return TARGET_LANGS.has(doc.languageId);
}

export function checkDocument(doc: vscode.TextDocument, intensity: Intensity): StyleIssue[] {
  const issues: StyleIssue[] = [];
  const text = doc.getText();
  const lines = text.split(/\r?\n/);

  // --- 行単位でチェック ---
  lines.forEach((line, i) => {
    // var使用
    const varMatch = /\bvar\s+([a-zA-Z_$][\w$]*)/.exec(line);
    if (varMatch) {
      const col = varMatch.index;
      issues.push({
        range: new vscode.Range(i, col, i, col + 3),
        ruleId: 'varUsage',
        message: pick(STYLE_TAUNTS.varUsage, intensity)
      });
    }

    // 悪い変数名（a, b, tmp, foo, hoge を単独宣言）
    const badNames = /\b(?:let|const|var)\s+(a|b|c|x|y|tmp|temp|foo|bar|hoge|piyo)\b/.exec(line);
    if (badNames) {
      const nameIdx = badNames.index + badNames[0].indexOf(badNames[1]);
      issues.push({
        range: new vscode.Range(i, nameIdx, i, nameIdx + badNames[1].length),
        ruleId: 'badVariableName',
        message: pick(STYLE_TAUNTS.badVariableName, intensity)
      });
    }

    // console.log残し
    const clog = /console\.(log|debug|info)\s*\(/.exec(line);
    if (clog) {
      issues.push({
        range: new vscode.Range(i, clog.index, i, clog.index + clog[0].length),
        ruleId: 'consoleLog',
        message: pick(STYLE_TAUNTS.consoleLog, intensity)
      });
    }

    // マジックナンバー（コード中の裸の数字、0/1/-1/2は除外）
    const magic = /(?<![\w."'])(\d{2,})(?![\w."'])/.exec(line);
    if (magic && !/^(10|100|1000)$/.test(magic[1])) {
      issues.push({
        range: new vscode.Range(i, magic.index, i, magic.index + magic[1].length),
        ruleId: 'magicNumber',
        message: pick(STYLE_TAUNTS.magicNumber, intensity)
      });
    }
  });

  // --- 関数の長さチェック（雑に function ～ 次の function or EOF） ---
  const funcRegex = /^(?:\s*)(?:function\s+\w+|(?:const|let|var)\s+\w+\s*=\s*(?:async\s*)?\(|(?:async\s+)?function\s*\(|\w+\s*\([^)]*\)\s*(?::\s*[^=]+)?\s*=>)/;
  let funcStart = -1;
  let braceDepth = 0;
  lines.forEach((line, i) => {
    if (funcStart < 0 && funcRegex.test(line)) {
      funcStart = i;
      braceDepth = 0;
    }
    if (funcStart >= 0) {
      for (const ch of line) {
        if (ch === '{') braceDepth++;
        else if (ch === '}') braceDepth--;
      }
      if (braceDepth === 0 && i > funcStart) {
        const length = i - funcStart + 1;
        if (length > 40) {
          issues.push({
            range: new vscode.Range(funcStart, 0, funcStart, lines[funcStart].length),
            ruleId: 'longFunction',
            message: pick(STYLE_TAUNTS.longFunction, intensity)
          });
        }
        funcStart = -1;
      }
    }
  });

  // --- ネスト深さチェック（インデントベース、雑） ---
  lines.forEach((line, i) => {
    const indent = line.match(/^(\s*)/)?.[1] ?? '';
    // タブ=1、スペース2=1、スペース4=1として計算（雑にスペース数/2）
    const depth = indent.includes('\t')
      ? indent.length
      : Math.floor(indent.length / 2);
    if (depth >= 5 && line.trim().length > 0) {
      issues.push({
        range: new vscode.Range(i, 0, i, line.length),
        ruleId: 'deepNest',
        message: pick(STYLE_TAUNTS.deepNest, intensity)
      });
    }
  });

  // --- コメント皆無チェック（100行以上でコメント0） ---
  if (lines.length >= 100) {
    const hasComment = /\/\/|\/\*|\*\//.test(text);
    if (!hasComment) {
      issues.push({
        range: new vscode.Range(0, 0, 0, Math.min(lines[0]?.length ?? 0, 1)),
        ruleId: 'noComment',
        message: pick(STYLE_TAUNTS.noComment, intensity)
      });
    }
  }

  // 同一ルール多発を抑制：ルールごとに最大3件
  const capped: StyleIssue[] = [];
  const counts = new Map<string, number>();
  for (const issue of issues) {
    const c = counts.get(issue.ruleId) ?? 0;
    if (c < 3) {
      capped.push(issue);
      counts.set(issue.ruleId, c + 1);
    }
  }

  return capped;
}
