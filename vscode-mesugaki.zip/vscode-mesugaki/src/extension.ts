import * as vscode from 'vscode';
import { ON_ERROR, ON_WARNING, ON_FIXED, BY_RULE, pick, categoryFor, Intensity } from './taunts';
import { checkDocument, shouldCheck } from './styleChecker';
import * as gitWatcher from './gitWatcher';

// 通知の連発を抑えるためのクールダウン
let lastNotifyAt = 0;
const NOTIFY_COOLDOWN_MS = 8000;

// ファイルごとの直近のエラー数
const lastErrorCount = new Map<string, number>();
// ファイルごとの前回時点の診断シグネチャセット（新規発生検出用）
const lastDiagSignatures = new Map<string, Set<string>>();

let diagnosticCollection: vscode.DiagnosticCollection;
let statusBar: vscode.StatusBarItem;

function getConfig() {
  const cfg = vscode.workspace.getConfiguration('mesugaki');
  return {
    enabled: cfg.get<boolean>('enabled', true),
    intensity: cfg.get<Intensity>('intensity', 'normal'),
    styleCheck: cfg.get<boolean>('styleCheck', true)
  };
}

function notify(message: string, kind: 'info' | 'warn' = 'info') {
  const now = Date.now();
  if (now - lastNotifyAt < NOTIFY_COOLDOWN_MS) {
    statusBar.text = `$(smiley) ${message}`;
    return;
  }
  lastNotifyAt = now;
  statusBar.text = `$(smiley) ${message}`;
  if (kind === 'warn') {
    vscode.window.showWarningMessage(message);
  } else {
    vscode.window.showInformationMessage(message);
  }
}

function runStyleCheck(doc: vscode.TextDocument, notifyOnFinding = false) {
  const { enabled, styleCheck, intensity } = getConfig();
  if (!enabled || !styleCheck || !shouldCheck(doc)) {
    diagnosticCollection.delete(doc.uri);
    return;
  }
  const issues = checkDocument(doc, intensity);
  const diagnostics = issues.map((issue) => {
    const d = new vscode.Diagnostic(
      issue.range,
      `[メスガキ先生] ${issue.message}`,
      vscode.DiagnosticSeverity.Information
    );
    d.source = 'mesugaki';
    d.code = issue.ruleId;
    return d;
  });
  diagnosticCollection.set(doc.uri, diagnostics);

  // 保存時にたまにトースト通知（25%）
  if (notifyOnFinding && issues.length > 0 && Math.random() < 0.25) {
    const pickIdx = Math.floor(Math.random() * issues.length);
    notify(issues[pickIdx].message, 'info');
  }
}

/** 診断のシグネチャ（差分検出用） */
function diagSignature(d: vscode.Diagnostic): string {
  const code =
    typeof d.code === 'object' && d.code !== null && 'value' in d.code
      ? String(d.code.value)
      : String(d.code ?? '');
  return `${code}|${d.range.start.line}|${d.range.start.character}|${d.message}`;
}

function handleDiagnosticsChange(e: vscode.DiagnosticChangeEvent) {
  const { enabled, intensity } = getConfig();
  if (!enabled) return;

  for (const uri of e.uris) {
    const all = vscode.languages.getDiagnostics(uri);
    // 自分の指摘は除外
    const external = all.filter((d) => d.source !== 'mesugaki');

    const key = uri.toString();
    const prevSigs = lastDiagSignatures.get(key) ?? new Set<string>();
    const currentSigs = new Set<string>();
    const newDiags: vscode.Diagnostic[] = [];

    for (const d of external) {
      const sig = diagSignature(d);
      currentSigs.add(sig);
      if (!prevSigs.has(sig)) {
        newDiags.push(d);
      }
    }
    lastDiagSignatures.set(key, currentSigs);

    const errorCount = external.filter(
      (d) => d.severity === vscode.DiagnosticSeverity.Error
    ).length;
    const prevError = lastErrorCount.get(key) ?? 0;
    lastErrorCount.set(key, errorCount);

    // 全部直った → ツンデレで褒める
    if (errorCount === 0 && prevError > 0) {
      notify(pick(ON_FIXED, intensity), 'info');
      continue;
    }

    // 新規診断があればルール別にディスパッチ
    if (newDiags.length === 0) continue;

    const errorNew = newDiags.filter(
      (d) => d.severity === vscode.DiagnosticSeverity.Error
    );
    const warnNew = newDiags.filter(
      (d) => d.severity === vscode.DiagnosticSeverity.Warning
    );

    let target: vscode.Diagnostic | undefined;
    let level: 'info' | 'warn' = 'info';

    if (errorNew.length > 0) {
      target = errorNew[Math.floor(Math.random() * errorNew.length)];
      level = 'warn';
    } else if (warnNew.length > 0) {
      // 警告のみの発生は33%だけ通知
      if (Math.random() >= 0.33) continue;
      target = warnNew[Math.floor(Math.random() * warnNew.length)];
      level = 'info';
    }

    if (!target) continue;

    const category = categoryFor(target.code as string | number | undefined);
    let message: string;
    if (category && BY_RULE[category]) {
      message = pick(BY_RULE[category], intensity);
    } else if (target.severity === vscode.DiagnosticSeverity.Error) {
      message = pick(ON_ERROR, intensity);
    } else {
      message = pick(ON_WARNING, intensity);
    }

    notify(message, level);
  }
}

export function activate(context: vscode.ExtensionContext) {
  diagnosticCollection = vscode.languages.createDiagnosticCollection('mesugaki');
  context.subscriptions.push(diagnosticCollection);

  statusBar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
  statusBar.text = '$(smiley) メスガキ先生 待機中';
  statusBar.tooltip = 'クリックで煽りON/OFF';
  statusBar.command = 'mesugaki.toggle';
  statusBar.show();
  context.subscriptions.push(statusBar);

  context.subscriptions.push(
    vscode.languages.onDidChangeDiagnostics(handleDiagnosticsChange)
  );

  context.subscriptions.push(
    vscode.workspace.onDidSaveTextDocument((doc) => runStyleCheck(doc, true))
  );
  context.subscriptions.push(
    vscode.workspace.onDidOpenTextDocument(runStyleCheck)
  );

  if (vscode.window.activeTextEditor) {
    runStyleCheck(vscode.window.activeTextEditor.document);
  }

  context.subscriptions.push(
    vscode.commands.registerCommand('mesugaki.toggle', async () => {
      const cfg = vscode.workspace.getConfiguration('mesugaki');
      const now = cfg.get<boolean>('enabled', true);
      await cfg.update('enabled', !now, vscode.ConfigurationTarget.Global);
      if (!now) {
        vscode.window.showInformationMessage('メスガキ先生: 起動したよ。');
        statusBar.text = '$(smiley) メスガキ先生 稼働中';
      } else {
        vscode.window.showInformationMessage('メスガキ先生: ふん、静かにしてあげる。');
        statusBar.text = '$(mute) メスガキ先生 OFF';
        diagnosticCollection.clear();
      }
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('mesugaki.praise', () => {
      const { intensity } = getConfig();
      notify(pick(ON_FIXED, intensity), 'info');
    })
  );

  // 設定変更を即時反映
  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration((e) => {
      if (!e.affectsConfiguration('mesugaki')) return;
      const { enabled, styleCheck } = getConfig();
      if (!enabled) {
        diagnosticCollection.clear();
        statusBar.text = '$(mute) メスガキ先生 OFF';
        return;
      }
      statusBar.text = '$(smiley) メスガキ先生 稼働中';
      if (!styleCheck) {
        diagnosticCollection.clear();
      } else if (vscode.window.activeTextEditor) {
        runStyleCheck(vscode.window.activeTextEditor.document);
      }
    })
  );

  // ファイルクローズ時に状態を掃除
  context.subscriptions.push(
    vscode.workspace.onDidCloseTextDocument((doc) => {
      const key = doc.uri.toString();
      lastErrorCount.delete(key);
      lastDiagSignatures.delete(key);
      diagnosticCollection.delete(doc.uri);
    })
  );

  // Git commit監視（雑なメッセージだと煽る）
  gitWatcher.setup(context, notify, () => getConfig().intensity).catch(() => {
    // Git拡張が無い環境では黙って諦める
  });
}

export function deactivate() {
  diagnosticCollection?.dispose();
  statusBar?.dispose();
}
