# Mesugaki Sensei（メスガキ先生）

コード書いてる横で煽ってくるVSCode拡張。

## 何ができるの

- **エラー監視**: エラーや警告が出ると煽り通知が飛んでくる
- **スタイル指摘**: 保存時にコードをチェックして、雑な書き方に文句をつけてくる（Diagnosticsとして表示）
- **たまに褒めてくれる**: エラー全部直したら、ツンデレっぽく認めてくれる
- **ステータスバー常駐**: クリックでON/OFF切り替え

## ルール別の台詞

LSPやESLintが返す診断の `code`（例: `no-unused-vars`, `@typescript-eslint/no-explicit-any`, TSの数値コード）
を見て、該当カテゴリの専用台詞を優先的に出す。マッピングは `src/taunts.ts` の `RULE_MAP` にある。
対応済み：`unused`（未使用変数）, `any_type`, `loose_equality`（`==`）, `debug_print`, `undefined_ref`,
`type_mismatch`, `null_safety`, `syntax_error`, `prefer_const`。未対応のcodeは汎用台詞にフォールバックする。

## 指摘してくるやつ（JS/TSのみ、保存時のスタイルチェック）

- `var` 使ってる
- 変数名が `a`, `tmp`, `foo`, `hoge` みたいな雑なやつ
- `console.log` 残しっぱなし
- マジックナンバー
- 関数が40行以上
- ネストが深すぎ（5階層以上）
- 100行以上でコメント皆無

## セットアップ

```bash
cd vscode-mesugaki
npm install
npm run compile
```

デバッグ実行するには、VSCodeでこのフォルダ開いて **F5** で拡張ホストが立ち上がる。

**初回はlaunch.jsonが無くてF5が効かないことがある**。その場合：
1. 左サイドバーの「実行とデバッグ」（三角+虫アイコン）を開く
2. 「create a launch.json file」リンクをクリック→「VS Code Extension Development」を選択
3. 生成された状態で再度F5

手動で作る場合は `.vscode/launch.json` にこの内容を置く：
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Run Extension",
      "type": "extensionHost",
      "request": "launch",
      "args": ["--extensionDevelopmentPath=${workspaceFolder}"],
      "outFiles": ["${workspaceFolder}/out/**/*.js"]
    }
  ]
}
```

起動すると別ウィンドウ（タイトルバーに `[Extension Development Host]` と表示）が開く。
そこでステータスバー右下に「😊 メスガキ先生 待機中」が出ていれば読み込み成功。

パッケージ化して自分の環境に入れる場合：

```bash
npm install -g @vscode/vsce
vsce package
# 出来た .vsix を「拡張機能」>「...」>「VSIXからインストール」で入れる
```

## 設定

- `mesugaki.enabled`: 有効/無効
- `mesugaki.intensity`: `soft` / `normal` / `spicy` — 煽りの強さ
- `mesugaki.styleCheck`: スタイルチェックのON/OFF

## コマンド

- `Mesugaki: 煽りON/OFF`
- `Mesugaki: 褒めて（無理やり）` — 気分が沈んだ時用

## 拡張のヒント

- `src/taunts.ts` に台詞を足せば量が増える
- `src/styleChecker.ts` にルール足せば指摘項目が増える。ちゃんとやるならASTパース（`typescript` パッケージのCompiler API）を使うと精度上がる
- 対象言語は今JS/TSだけ。`TARGET_LANGS` を編集すれば増やせる
